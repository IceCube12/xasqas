<ul class="navbar-nav">
<li class="nav-item px-6 py-4 font-medium text-gray-900">
<a class="nav-link active" aria-current="page" href=<?php echo e('/'); ?>>Home</a>
</li>
<li class="nav-item px-6 py-4 font-medium text-gray-900">
<a class="nav-link" href=<?php echo e('/editprofile'); ?>>Edit Profile</a>
</li>

<li class="nav-item px-6 py-4 font-medium text-gray-900">
<a class="nav-link" href=<?php echo e("/logout"); ?>>Logout</a>
</li>

</ul><?php /**PATH C:\laravelprojects\laravel-is\resources\views/components/items.blade.php ENDPATH**/ ?>